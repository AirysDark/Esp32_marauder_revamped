.. toctree::
   :maxdepth: 2

.. include:: ../../README.rst
   :end-before: Documentation

Class Documentation
-------------------
.. doxygenclass:: MicroNMEA
   :project: MicroNMEA
   :members:

----

This documentation was built using ArduinoDocs_.

.. _ArduinoDocs: http://arduinodocs.readthedocs.org
